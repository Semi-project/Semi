package dto.member;

public class Member {

}
